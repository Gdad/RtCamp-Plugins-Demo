 jQuery(document).ready(function($) {
    $('#banner-slide').bjqs({
        animtype      : 'slide',
        height        : 320,
        width         : 620,
        responsive    : true
    });
});