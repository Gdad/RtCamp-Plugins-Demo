<?php 
/*Silence is golden*/